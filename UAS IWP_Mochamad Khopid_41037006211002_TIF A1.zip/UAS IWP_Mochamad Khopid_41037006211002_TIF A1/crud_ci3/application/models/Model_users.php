<?php
class Model_users extends CI_model{
	
	function load_data(){
		$this->db->order_by('id','DESC');
		$query = $this->db->get('users');
		return $query;
	}
	function simpan_data($data){
		$this->db->insert('users',$data);
		return true;
	}
	function load_data_single($id){
		$this->db->where('id',$id);
		$query = $this->db->get('users');
		return $query;
	}
	function update_data($id,$data){
		$this->db->where('id',$id);
		$this->db->update('users',$data);
		return true;
	}
	function delete_data($id){
		$this->db->where('id',$id);
		$this->db->delete('users');
		return true;
	} 

}
