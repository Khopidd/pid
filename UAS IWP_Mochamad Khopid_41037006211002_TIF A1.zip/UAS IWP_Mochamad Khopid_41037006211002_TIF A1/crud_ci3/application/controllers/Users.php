<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('model_users');
	}

	public function index(){

		$x['data'] = $this->model_users->load_data();
		$this->load->view('users/data_user',$x);
	}

	function add_user(){
		$this->load->view('users/input_data');
	}
	function simpan_data(){
		$id 		    = $this->input->post('id');
		$first_name     = $this->input->post('first_name');
		$code 	        = $this->input->post('code');
		$tanggal_lahir 	= $this->input->post('tanggal_lahir');
		$tempat_lahir 	= $this->input->post('tempat_lahir');
		$tanggal_pendaftaran = $this->input->post('tanggal_pendaftaran');
		
		if($foto !=='') {
			$file_name 						= str_replace(' ','_',$first_name)."_".str_replace(' ','_',$code);
			$config['upload_path']          = './assets/images/';
			$config['allowed_types']        = 'gif|jpg|jpeg|png';
			$config['overwrite']            = true;
			$config['file_name']            = $file_name;
			$config['max_size']             = 2048; 

			$this->load->library('upload', $config);

		{
					
				$filename=  $this->upload->data('file_name');
					
				$data = array(
					'first_name' 	=> $first_name,
					'code'	        => $code,
					'tanggal_lahir'	=> $tanggal_lahir,
					'tempat_lahir'	=> $tempat_lahir,
					'tanggal_pendaftaran' => $tanggal_pendaftaran,
				);
				$this->model_users->simpan_data($data);
				redirect('users');
			}
		}

  










	} 
	function edit(){
		$x['data'] = $this->model_users->load_data_single($this->uri->segment(3));
		$this->load->view('users/edit_data',$x);
	}
	function update_data(){
		$id 		    = $this->input->post('id');
		$first_name     = $this->input->post('first_name');
		$code 	        = $this->input->post('code');
		$tanggal_lahir 	= $this->input->post('tanggal_lahir');
		$tempat_lahir 	= $this->input->post('tempat_lahir');
		$tanggal_pendaftaran = $this->input->post('tanggal_pendaftaran');


		if($foto) {
			//Upload foto 
			$file_name 						= str_replace(' ','_',$first_name)."_".str_replace(' ','_',$code);
			$config['upload_path']          = './assets/images/';
			$config['allowed_types']        = 'gif|jpg|jpeg|png';
			$config['overwrite']            = true;
			$config['file_name']            = $file_name;
			$config['max_size']             = 2048; 

			$this->load->library('upload', $config);

			if($this->upload->do_upload('foto')) {
				
				$filename=  $this->upload->data('file_name');
				
				$data = array(
					'first_name' 	=> $first_name,
					'code'	        => $code,
					'tanggal_lahir'	=> $tanggal_lahir,
					'tempat_lahir'	=> $tempat_lahir,
					'tanggal_pendaftaran' => $tanggal_pendaftaran,

				);
				$this->model_users->update_data($id,$data);
				redirect('users');
			}
		}
		else{
			$data = array(
				'first_name' 	=> $first_name,
				'code'	        => $code,
				'tanggal_lahir'	=> $tanggal_lahir,
				'tempat_lahir'	=> $tempat_lahir,
				'tanggal_pendaftaran' => $tanggal_pendaftaran,
	
				);

			$this->model_users->update_data($id,$data);
		}
		redirect('users');
	}
	function delete(){
		$id = $this->uri->segment(3);

		$data_user = $this->model_users->load_data_single($id)->row_array();
		if(file_exists('./assets/images/'.$data_user['foto'])){
			unlink('./assets/images/'.$data_user['foto']);
		}

		$this->model_users->delete_data($id);
		redirect('users');
	}
}
