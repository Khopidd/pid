<html>
<head>
	<title>Crud Ci3</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<h2 class="text-center">Perpustakaan Khopidd</h2>
		<h4 class="text-center">Pinjam Buku Disini Aja Cuyy<b></b></h4>
		<div class="table-responsive">
			<div align="right">
				<a href="<?php echo base_url()?>users/add_user" class="btn btn-primary btn-sm">Add Data</a>
			</div>
			<br>
			<table class="table tale-striped table-bordered">
				<thead>
					<tr>
						<th class="text-center">No.</th>
						<th class="text-center">Nama</th>
						<th class="text-center">Kode</th>
						<th class="text-center">Tanggal Lahir</th>
						<th class="text-center">Tempat Lahir</th>
						<th class="text-center">Tanggal Pendaftaran</th>
						<th class="text-center">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$no=1;
					foreach ($data->result() as $row) {
						
					 	echo '
						 	<tr>
							 	<td class="text-center">'.$no.'.</td>
							 	<td class="text-center">'.$row->first_name.'</td>
							 	<td class="text-center">'.$row->code.'</td>
							 	<td class="text-center">'.$row->tanggal_lahir.'</td>
							 	<td class="text-center">'.$row->tempat_lahir.'</td>
							 	<td class="text-center">'.$row->tanggal_pendaftaran.'</td>
							 	<td class="text-center">
							 		<a href="'.base_url().'users/edit/'.$row->id.'" class="btn btn-info">Edit</a>
							 		<a href="'.base_url().'users/delete/'.$row->id.'" class="btn btn-danger">Delete</a>
							 	</td>
						 	</tr>
						 	';
						 $no++;
					 } 
					?>
				</tbody>
			</table>
		</div>
	</div>

</body>
</html>