<html>
<head>
	<title>Crud Ci3</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<style>
	.box {
		width:60%;
		margin:0 auto;
		background-color: #fff;
		border: 1px solid #ccc;
		border-radius: 5px
		padding:10px;
	}
	</style>
</head>
<body>
	<div class="container">
		<h2 class="text-center">Perpustakaan Khopidd</h2>
		<h4 class="text-center">Pinjam Buku Disini Aja Cuyy
			<br><br><b>Edit Data</b></h4>
		<div class="box box-primary">
		<br>
		<form method="post" action="<?php echo base_url()?>users/update_data" enctype="multipart/form-data">
			<?php 
			foreach ($data->result() as $row){
				$id 			= $row->id;
				$first_name 	= $row->first_name;
				$code  			= $row->code;
				$tanggal_lahir 	= $row->tanggal_lahir;
				$tempat_lahir 	= $row->tempat_lahir;
				$tanggal_pendaftaran 			= $row->tanggal_pendaftaran;
				$status 		= $row->status;
			?>
			<div class="form-group">
				<label class="control-label col-sm-12">Nama</label>
				<div class="col-sm-12">
					<input type="hidden" class="form-control" name="id" value="<?php echo $id?>"/>
					<input type="text" class="form-control" name="first_name" value="<?php echo $first_name?>"/>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-12">Code</label>
				<div class="col-sm-12">
					<input type="text" class="form-control" name="code" value="<?php echo $code?>"/>
				</div>
			</div> <br>
			<div class="form-group">
				<label class="control-label col-sm-12">Tanggal Lahir</label>
				<div class="col-sm-12">
					
		<input type="datetime-local" class="form-control" name="tanggal_lahir"/> <br>
	              
					<br>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-12">Tempat Lahir</label>
				<div class="col-sm-12">
					<input type="text" class="form-control" name="tempat_lahir" />
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-12">Tanggal Pendaftaran</label>
				<div class="col-sm-12">
					<input type="datetime-local" class="form-control" name="tanggal_pendaftaran" />
				</div>
			</div>
			
			<div class="form-group">
				<div class="text-center" >
					<label class="control-label col-sm-12">
						<br>
						<br>
					</label>
					<input type="submit" name ="update" class="btn btn-primary" value="Update"/>
					<a href="<?php echo base_url()?>users" name ="back" class="btn btn-default" >Batal</a>
				</div>
			</div>
			<?php 
				}
			?>
		</form>
		</div>
	</div>
</body>
</html>