<html>
<head>
	<title>Crud Ci3</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<style>
	.box {
		width:60%;
		margin:0 auto;
		background-color: #fff;
		border: 1px solid #ccc;
		border-radius: 5px
		padding:10px;
	}
	</style>
</head>
<body>
	<div class="container">
		<h2 class="text-center">Perpustakaan Khopidd</h2>
		<h4 class="text-center">Pinjam Buku Disini Aja Cuyy
			<br><br><b>Anggota Baru Yaaa :)</b></h4>
		<div class="box box-primary">
		<br>
		<form method="post" action="<?php echo base_url()?>users/simpan_data" enctype='multipart/form-data'>
			<div class="form-group">
				<label class="control-label col-sm-12">Nama</label>
				<div class="col-sm-12">
					<input type="text" class="form-control" name="first_name" />
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-12">Code</label>
				<div class="col-sm-12">
					<input type="text" class="form-control" name="code" />
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-12">Tanggal Lahir</label>
				<div class="col-sm-12">
					
		<input type="datetime-local" class="form-control" name="tanggal_lahir"/> <br>
	                
					<br>
				</div>
			</div>

			<div class="form-group">
				<label class="control-label col-sm-12">Tempat Lahir</label>
				<div class="col-sm-12">
					<input type="text" class="form-control" name="tempat_lahir" />
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-sm-12">Tanggal Pendaftaran</label>
				<div class="col-sm-12">
					<input type="datetime-local" class="form-control" name="tanggal_pendaftaran" />
				</div>
			</div>

			
			
			<div class="form-group">
				<div class="text-center" >
					<label class="control-label col-sm-12">
						<br>
						<br>
					</label>
					<input type="submit" name ="insert" class="btn btn-primary" value="Simpan"/>
					<a href="<?php echo base_url()?>users" type="btn" class="btn btn-default" >Batal</a>
				</div>
			</div>
		</form>
		</div>
	</div>
</body>
</html>